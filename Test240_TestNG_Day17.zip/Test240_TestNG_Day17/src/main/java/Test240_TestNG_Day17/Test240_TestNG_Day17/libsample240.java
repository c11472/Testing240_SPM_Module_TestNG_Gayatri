package Test240_TestNG_Day17.Test240_TestNG_Day17;

public class libsample240 {
	public void testmethod1() {
		System.out.println("Non static method");
	}
	public static void testmethod2() {
		System.out.println("Static method");
			}
}
