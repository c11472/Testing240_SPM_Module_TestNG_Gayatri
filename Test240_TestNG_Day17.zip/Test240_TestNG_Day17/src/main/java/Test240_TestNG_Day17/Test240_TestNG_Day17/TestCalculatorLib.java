package Test240_TestNG_Day17.Test240_TestNG_Day17;

import java.util.Scanner;

public class TestCalculatorLib {
	Scanner c;
	
	public int addition(int n, int n1) {
	    c = new Scanner(System.in);
	    n=c.nextInt();
	    n1=c.nextInt();
		int sum=n+n1;
		return sum;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
