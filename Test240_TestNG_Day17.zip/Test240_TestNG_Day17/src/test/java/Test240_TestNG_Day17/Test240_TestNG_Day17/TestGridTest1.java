package Test240_TestNG_Day17.Test240_TestNG_Day17;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class TestGridTest1 
{
WebDriver driver;
@Test
public void TestOne() throws MalformedURLException {
	WebDriver dr;;
    String nodeURL = "http://172.28.16.1:6666/wd/hub";
    System.out.println("Chrome Browser Initiated");
    DesiredCapabilities capabilities = DesiredCapabilities.chrome();            
    capabilities.setBrowserName("chrome");
    System.out.println("Chrome Browser Initiated");
    driver = new RemoteWebDriver(new URL(nodeURL), capabilities);
    //System.out.println("Remote node connected");
    driver.get("https://www.google.com");
    
}
}