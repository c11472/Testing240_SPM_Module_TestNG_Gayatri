package Test240_TestNG_Day17.Test240_TestNG_Day17;

import org.testng.annotations.Test;

public class MyCalculatror {
  @Test
  public void f() {
  }
}
