package Test240_TestNG_Day17.Test240_TestNG_Day17;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class Test240_Samplescript1 {
	public static void main(String args[]) throws MalformedURLException {
		/*WebDriver driver;
	    String nodeURL = "http://172.28.16.1:6666/wd/hub";
	    System.out.println("Chrome Browser Initiated");
	    DesiredCapabilities capabilities = new  DesiredCapabilities();            
	    capabilities.setBrowserName("chrome");*
	    /
	     * 
	     */
		
	    String nodeURL = "http://172.28.16.1:6666/wd/hub";

		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.setCapability("browserVersion", "100");
		chromeOptions.setCapability("platformName", "Windows");
		// Showing a test name instead of the session id in the Grid UI
		chromeOptions.setCapability("se:name", "My simple test"); 
		// Other type of metadata can be seen in the Grid UI by clicking on the 
		// session info or via GraphQL
		chromeOptions.setCapability("se:sampleMetadata", "Sample metadata value"); 
		WebDriver driver = new RemoteWebDriver(new URL(nodeURL),chromeOptions);
		driver.get("http://www.google.com");
		driver.quit();   
	}
}
