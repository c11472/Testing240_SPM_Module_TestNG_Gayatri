package Test240_TestNG_Day17.Test240_TestNG_Day17;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class SeleniumGridTest {
    public static void main(String[] args) 
    {
        // Define the desired capabilities
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setBrowserName("chrome");

        // Set the hub URL
        String NodeOne = "http://172.28.16.1:6666/wd/hub";

        // Initialize the remote WebDriver
        WebDriver driver = null;
        try {
            driver = new RemoteWebDriver(new URL(NodeOne), capabilities);
        } 
        catch (MalformedURLException e) {
            e.printStackTrace();
        }

        // Open a website
        driver.get("https://www.google.com");

        // Print the title of the page
        System.out.println("Title: " + driver.getTitle());

        // Close the browser
        driver.quit();
    }
}