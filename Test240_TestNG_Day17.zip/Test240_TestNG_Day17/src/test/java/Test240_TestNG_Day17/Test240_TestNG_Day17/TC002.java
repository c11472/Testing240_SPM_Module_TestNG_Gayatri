package Test240_TestNG_Day17.Test240_TestNG_Day17;


	
			import org.openqa.selenium.WebDriver;
			import org.openqa.selenium.chrome.ChromeOptions;
			import org.openqa.selenium.remote.RemoteWebDriver;

			import java.net.MalformedURLException;
			import java.net.URL;

			public class TC002 {
			    public static void main(String[] args) {
			        // Define the Chrome options
			        ChromeOptions options = new ChromeOptions();

			        // Set the hub URL
			        String hubURL = "http://172.28.16.1:4444/wd/hub";

			        // Initialize the remote WebDriver
			        WebDriver driver = null;
			        try {
			            driver = new RemoteWebDriver(new URL(hubURL), options);
			        } 
			        catch (MalformedURLException e) {
			            e.printStackTrace();
			        }

			        // Open a website
			        driver.get("https://www.google.com");

			        // Print the title of the page
			        System.out.println("Title: " + driver.getTitle());

			        // Close the browser
			        driver.quit();
			    }
			}
				
