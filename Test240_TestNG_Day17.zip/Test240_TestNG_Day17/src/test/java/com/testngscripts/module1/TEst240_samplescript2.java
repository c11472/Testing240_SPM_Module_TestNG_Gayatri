package com.testngscripts.module1;

import org.testng.annotations.Test;

public class TEst240_samplescript2 {
  @Test
  public void functiontest001() {
	  System.out.println("Display hello world !");
	  }
	  
  }  

