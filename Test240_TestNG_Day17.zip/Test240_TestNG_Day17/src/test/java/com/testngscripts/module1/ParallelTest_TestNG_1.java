package com.testngscripts.module1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ParallelTest_TestNG_1 {
	  WebDriver wd;
	  @Test
	  public void f() {
		  wd=new FirefoxDriver();
		  wd.get("https://www.amazon.in/");
		  System.out.println("The thread ID for Firefox is " + Thread.currentThread().getId());


		  
	  }
	  
	  @Test
	  public void f1() {
		  wd = new ChromeDriver();
		  wd.get("https://www.amazon.in/");
		  System.out.println("The thread ID for Chrome is " + Thread.currentThread().getId());

		  
	  }
	}
