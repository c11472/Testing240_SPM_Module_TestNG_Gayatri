package com.testngscripts.module1;

import org.testng.annotations.Test;

public class Testcase0010 {
  @Test
  public void f() {
  }
}
