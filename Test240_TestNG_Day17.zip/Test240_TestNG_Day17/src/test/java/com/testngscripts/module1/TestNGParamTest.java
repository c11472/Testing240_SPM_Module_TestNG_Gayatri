package com.testngscripts.module1;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNGParamTest {
	@DataProvider(name = "testdatatable")
	public Object[][] dataProvFunc() {
		return new Object[][]{ { "Ajeeth P",10067,67000.50 }, { "Kalpana S", 24535,34000.50 },
				{ "Sujatha S", 56456 ,31700.00} };
	}
	
	@Test(dataProvider = "testdatatable")
	public void search(String EmpName, int EmpID,double EmpSal)  {
      System.out.println(EmpName+ " " + EmpID + " "+EmpSal );	
      
			
	}


}
