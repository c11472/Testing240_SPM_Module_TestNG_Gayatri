package com.testngscripts.module1;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
/***
 * 1. Enter user name 
 * 2. Enter password
 * 3. validate user name 
 * 4. validate password
 * 
 *
 */

public class Test240_TestdataAccess {
 String filepath = "./TestData/testdatafortesting.properties";
 FileReader fr;
 Properties p;
 String unm , pwd;
 Scanner c; // just for input
  @BeforeTest
  public void setup() throws IOException {
	 fr = new FileReader(filepath);
	 p = new Properties();
	 p.load(fr);
	 c = new Scanner(System.in);
	 
  }
  
  @Test(priority=1)
  public void enter_details() {
	  unm = p.getProperty("username");
	  pwd = p.getProperty("password");
	  System.out.println(unm + " "+ pwd);
  }
  
  @Test(priority=2)
  public void validate_login() {
	  System.out.println("Enter the user name");
	  String userinp1 = c.next();
	  System.out.println("Enter thepassword");
	  String pass1 = c.next();
	  
	  
	/*  if(userinp1.equals(unm) && pass1.equals(pwd) ) {
		  System.out.println("Successful login");
		  
	  }
	  else {
		  System.out.println("Enter valid credentials");
	  }*/
	  SoftAssert softAssert = new SoftAssert();
	  softAssert.assertEquals(userinp1, "testtyrt");
	  
	  
	 
	
	 // Assert obj = new Assert();
	 // Assert.assertEquals(userinp1, unm);
	  System.out.println("the user name and password are fetched from data source");
  }
  
  @Test(enabled=false)
  public void dummytest() {
	  System.out.println("Remoced feature");
  }
  
  @AfterTest
  public void teatdown() throws IOException {
	  
	  // close the file pointers
	  
	  fr.close();
	  p.clear();
  }
}
