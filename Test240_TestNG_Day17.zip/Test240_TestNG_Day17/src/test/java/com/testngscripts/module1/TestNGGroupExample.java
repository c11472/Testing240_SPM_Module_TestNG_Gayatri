package com.testngscripts.module1;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNGGroupExample {

    // This test belongs to the "smoke" group
    @Test(groups = "smoke")
    public void function1() {
        System.out.println("Smoke Group Test");
    }

    // This test belongs to the "regression" group
    @Test(groups = "regression")
    public void function2() {
        System.out.println("Regression Group Test");
    }
    
    @Test(groups = "smoke")
    public void function10() {
        System.out.println("Smoke Group Test2");
    }


    // This test belongs to both "smoke" and "regression" groups
    @Test(groups = "smoke")
    public void function3() {
        System.out.println("Smoke Group Test2");
    }

    // This test belongs to the "performance" group
    @Test(groups = "sanity")
    public void testMethod4() {
        System.out.println("Sanity Group Test");
    }
}
