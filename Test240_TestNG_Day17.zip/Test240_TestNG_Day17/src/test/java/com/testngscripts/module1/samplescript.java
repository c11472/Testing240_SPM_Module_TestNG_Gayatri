package com.testngscripts.module1;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class samplescript {
  @BeforeSuite
  public void suitelevel_setup() {
	  System.out.println("Please clear the browser history");
  }
  @Test
  public void dummymethod() {
	  System.out.println("This is a dummy method");
  }
  
  @AfterSuite
  
  public void suitelevel_teardown() {
	  System.out.println("Please clear the cookies");
  }
  
  
}
