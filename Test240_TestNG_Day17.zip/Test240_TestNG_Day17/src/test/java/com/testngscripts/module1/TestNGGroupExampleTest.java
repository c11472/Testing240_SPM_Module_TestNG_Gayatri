package com.testngscripts.module1;

import org.testng.annotations.Test;

public class TestNGGroupExampleTest {
  @Test
  public void f() {
  }
}
