package com.testngscripts.module1;

import org.testng.annotations.Test;

import Test240_TestNG_Day17.Test240_TestNG_Day17.TestCalculatorLib;

public class MyCalculatortest {
	
	TestCalculatorLib calculate = new TestCalculatorLib();
  @Test
  public void test_addition() {
	 int addval =  calculate.addition(15, 24);
	 System.out.println(addval);
  }
}
