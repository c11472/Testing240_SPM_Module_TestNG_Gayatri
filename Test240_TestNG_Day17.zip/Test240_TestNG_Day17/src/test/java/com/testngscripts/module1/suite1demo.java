package com.testngscripts.module1;

import org.testng.annotations.Test;

public class suite1demo {
  @Test
  public void f() {
  }
}
