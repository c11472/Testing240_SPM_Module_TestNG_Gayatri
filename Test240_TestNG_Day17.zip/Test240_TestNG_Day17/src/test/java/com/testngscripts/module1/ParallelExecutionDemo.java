package com.testngscripts.module1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ParallelExecutionDemo {
WebDriver wd;
  @Test
  public void f1() {
	  wd = (WebDriver) new FirefoxDriver();
  }
  
  @Test
  public void f2() {
	  wd = (WebDriver) new ChromeDriver();
	  
	  wd=new ChromeDriver();
  }
}
