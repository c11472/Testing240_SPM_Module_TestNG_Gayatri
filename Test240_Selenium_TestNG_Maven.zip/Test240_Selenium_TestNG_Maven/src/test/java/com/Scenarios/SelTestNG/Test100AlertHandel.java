package com.Scenarios.SelTestNG;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Test100AlertHandel {
  @Test
  public void f() throws InterruptedException {
	  WebDriver wd = new FirefoxDriver();
	  wd.get("https://mail.rediff.com/cgi-bin/login.cgi");
	  wd.findElement(By.xpath("//input[@id=\"login1\"]")).sendKeys("testdata@gmail.com");
       
	  
	  wd.findElement(By.xpath("//*[@name=\"proceed\"]")).click(); //
	  //alert window
	  //Thread.sleep(2000);
	  Alert alt = wd.switchTo().alert(); 
	  
	 // alt.accept(); // handling the alert
	  
	 String alertmessage= alt.getText();
	 System.out.println(alertmessage);
	 alt.accept();
	  
	  //System.out.println("Hello");
	  wd.findElement(By.id("password")).sendKeys("password123"); // allowing to continue
	  
	  
	  
	  
  }
}
