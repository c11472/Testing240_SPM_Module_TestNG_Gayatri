package com.Scenarios.SelTestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ParallelRunTest {
WebDriver wd;
  @Test
  public void f1() {
	  wd = new FirefoxDriver();
     // System.out.println( Thread.currentThread().getId());

	  
	  
	  
  }
  @Test
  public void f2() {
	  wd=new ChromeDriver();
     // System.out.println(Thread.currentThread().getId());

	  
  }
}
