package com.Scenarios.SelTestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import junit.framework.Assert;

public class Scenario1TestNGAuto {
	WebDriver wd;
@Test(priority=1)
  public void Launch_App() {
	  wd=new FirefoxDriver();
	  wd.get("https://www.amazon.in");
	  System.out.println("world");
	    }
  
  @Test(priority=2)
  public void Enter_SearchString() {
	 WebElement search1= wd.findElement(By.id("twotabsearchtextbox"));
	 search1.sendKeys("C with datastructure");	  
  }
  @Test(priority=3)
  public void Click_Search_Button() {
	 WebElement searchbutton1 = wd.findElement(By.id("nav-search-submit-button"));
	  searchbutton1.click();
	  System.out.println("Test methods");
	  
  }
  
  @Test(priority=4)
  public void closeDriver() {
	  WebElement price = wd.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[1]/div/span[1]/div[1]/div[3]/div/div/span/div/div/div/div[2]/div/div/div[3]/div[1]/div/div[1]/div[2]/div[1]/a/span/span[2]/span[2]"));
	  
	  System.out.println(price.getText());
	  
	  Assert.assertEquals("617", price.getText());
  }
}
