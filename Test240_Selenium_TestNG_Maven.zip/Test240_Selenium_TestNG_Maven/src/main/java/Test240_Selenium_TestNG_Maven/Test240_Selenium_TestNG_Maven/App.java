package Test240_Selenium_TestNG_Maven.Test240_Selenium_TestNG_Maven;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
