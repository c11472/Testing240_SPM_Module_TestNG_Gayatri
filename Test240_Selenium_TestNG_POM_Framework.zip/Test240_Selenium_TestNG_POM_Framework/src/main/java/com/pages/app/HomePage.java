package com.pages.app;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class HomePage {
	
	
	WebDriver wd; // step-1
	
	Properties p;
	FileReader F;
	
	String Exp_Title = "Online Shopping site in India:";
	
	// Create the WebElements
	
	By searchstr=By.xpath("//input[@id=\"twotabsearchtextbox\"]");
	By serachButton = By.xpath("//*[@id=\"nav-search-submit-button\"]");
	
	// init the WebDriver
	
    public void init_HomePage(WebDriver wd) {
    	this.wd=wd;
    	
    }
    
    // Core automation scripts in different methods
    
    public void invoke_amazon_in_firefox() throws IOException {
    	wd = new FirefoxDriver();
    	
    	p=new Properties();
    	F=new FileReader("./TestConfig/config.properties");
    	p.load(F);
    
    	wd.get(p.getProperty("BaseUrl"));
    	String actTitle = wd.getTitle();
    	System.out.println(actTitle);
    	
    	if(actTitle.contains(Exp_Title)) {
    		System.out.println("The application has invoked successfully");
    	}
    	else {
    		System.out.println("The url is wrong");
    	}
    	
    }
    
    
    
    public  void Enter_SearchString() {
    	if(wd.findElement(searchstr).isDisplayed()) {
    	wd.findElement(searchstr).sendKeys(p.getProperty("inputdata1"));
    	}
    	else {
    		System.out.println("The element is not present");
    		
    	}
    	
    }
    
    public void Click_On_Search_Button() {
     if(wd.findElement(serachButton).isDisplayed()) {
    	wd.findElement(serachButton).click();
    }
     else {
    	 System.out.println("button is not available");
     }
    }
}
    
