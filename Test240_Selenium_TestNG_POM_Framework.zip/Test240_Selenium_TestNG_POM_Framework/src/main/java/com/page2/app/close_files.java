package com.page2.app;

import org.openqa.selenium.WebDriver;

public class close_files {
	WebDriver wd;
	
	//Locators
	
	
	// init
	
	public void init_closeFiles(WebDriver wd) {
		this.wd=wd;
		
	}
	
	public void close_browser() {
		wd.close();
	}
	
	public void testsample() {
		System.out.println("sample data + "+ wd.getTitle());
	}
	

}
