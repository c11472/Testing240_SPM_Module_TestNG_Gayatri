package com.scripts.app;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.page2.app.close_files;
import com.pages.app.HomePage;

public class Amazon_Script1 {
	
  WebDriver wd = new FirefoxDriver();
  
  
  //Page Objects
  
  HomePage HomePageObject = new HomePage();
  close_files closeobj = new close_files();
  @Test(priority=1)
  public void Method_Module1() throws IOException {
	  HomePageObject.init_HomePage(wd); //init
	 // HomePageObject.invoke_amazon_in_firefox();
	 // HomePageObject.Enter_SearchString();
	 // HomePageObject.Click_On_Search_Button();
  }
  @Test(priority=2)
  public void Method_Module2() throws Exception {
	  HomePageObject.invoke_amazon_in_firefox();  
  }
  @Test(priority=3)
  public void Method_Module3() {
	  HomePageObject.Enter_SearchString();
  }
  
  @Test(priority=4)
  public void Method_Module4() {
	  HomePageObject.Click_On_Search_Button();
  }
  
  @Test(priority=5)
  public void closeinstance() {
     closeobj.init_closeFiles(wd);	
     closeobj.testsample();
     closeobj.close_browser();
  }
  
}