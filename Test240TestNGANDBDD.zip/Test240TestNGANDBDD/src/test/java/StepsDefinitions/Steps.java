package StepsDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class Steps {
	WebDriver wd;
	
	@Given("The user is in login page of jpetstore app")
	public void laoginpage() {
		wd=new FirefoxDriver();
		wd.get("https://petstore.octoperf.com/actions/Account.action;jsessionid=2D69C5EFF6E376BD1CB9E2DD68FDD736?signonForm=");
		
	}
	@When("^The user enters the (.*) and (.*)$") 
	public void enterCredentials(String username,String password) {
		wd.findElement(By.name("username")).sendKeys(username);
		wd.findElement(By.name("password")).sendKeys(password);
	}
    

}
