package packagerunner;
import org.testng.annotations.Test;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;


	@CucumberOptions(features = "src/test/FeatureFiles",
			glue = "StepsDefinitions",
			tags="@tag1")
public  class runnertest2 extends AbstractTestNGCucumberTests 
{
		
		
}



