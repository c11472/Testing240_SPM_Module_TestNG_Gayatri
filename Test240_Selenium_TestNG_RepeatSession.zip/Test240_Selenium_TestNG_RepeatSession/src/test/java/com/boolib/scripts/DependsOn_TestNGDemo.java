package com.boolib.scripts;

import org.testng.annotations.Test;

public class DependsOn_TestNGDemo {
    @Test
    public void MethodOne() {
        System.out.println("This is method one");
    }

    @Test(dependsOnMethods = { "MethodOne","MethodThree"})
    public void MethodTwo() {
        System.out.println("This is method two");
       
    }
    
    @Test
    public void MethodThree() {
        System.out.println("This is method three");
    }


    
}
