package com.boolib.scripts;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestCase_BookLib1 {
	WebDriver wd;
	
	//Object for the library
	BooksLib_Lib1 obj = new BooksLib_Lib1();
	
	//Create all the webElements
	/*WebElement firstName = wd.findElement(By.xpath("//*[@placeholder=\"Your First Name\"]"));
	WebElement LastName = wd.findElement(By.xpath("//*[@placeholder=\"Your Last Name\"]"));
	WebElement EmailId = wd.findElement(By.xpath("//*[@placeholder=\"acbde@xyz.com\"]"));
	WebElement PhoneNum=wd.findElement(By.xpath("//*[@placeholder=\"9999999999\"]"));
	WebElement PinCode = wd.findElement(By.xpath("//*[@placeholder=\"000000\"]"));
	String ExpectedMessage = "Sucessful registration";
	WebElement SubmitButton = wd.findElement(By.xpath("//div[contains(text(),\"Next\")]"));
   */
  @Test(priority=1)
  public void Navigate_To_Registartion_Page() {
	   wd=new FirefoxDriver();

       wd.get("https://justbooks.in/");

	   wd.navigate().to("https://justbooks.in/signup");
  }
  

  
 @Test(enabled=false)
  public void Form_DataEntry() {
	 
	    WebElement firstName = wd.findElement(By.xpath("//*[@placeholder=\"Your First Name\"]"));
		WebElement LastName = wd.findElement(By.xpath("//*[@placeholder=\"Your Last Name\"]"));
		WebElement EmailId = wd.findElement(By.xpath("//*[@placeholder=\"acbde@xyz.com\"]"));
		WebElement PhoneNum=wd.findElement(By.xpath("//*[@placeholder=\"9999999999\"]"));
		WebElement PinCode = wd.findElement(By.xpath("//*[@placeholder=\"000000\"]"));
		String ExpectedMessage = "Sucessful registration";
		WebElement SubmitButton = wd.findElement(By.xpath("//div[contains(text(),\"Next\")]"));
	//    WebElement messageAct = wd.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/form/div[5]/div"));
	  firstName.sendKeys("Gayatri");
	  LastName.sendKeys("Mishra");
	  EmailId.sendKeys("gayatrimis1@gmail.com");
	  PhoneNum.sendKeys("9191919191");
	  PinCode.sendKeys("123123");
	  wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  SubmitButton.click();
	  
      }
 @Test(priority=2)
 public void Enter_First_Name() {
	// WebElement firstName = wd.findElement(By.xpath("//*[@placeholder=\"Your First Name\"]"));

	 //firstName.sendKeys("testuser1");
	 obj.First_Name_Entry();
 }
 
 @Test (priority=3)
 public void Enter_Second_Name() {
	 WebElement LastName = wd.findElement(By.xpath("//*[@placeholder=\"Your Last Name\"]"));
	 LastName.sendKeys("testtest");
	 
 }
 
}
	  
	  
	  
	  

  
  
  

