package Test240_Selenium_TestNG_RepeatSession.Test240_Selenium_TestNG_RepeatSession;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
